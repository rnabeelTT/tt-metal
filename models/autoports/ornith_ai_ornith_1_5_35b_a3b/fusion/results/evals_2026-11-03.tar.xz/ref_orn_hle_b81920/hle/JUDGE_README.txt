HLE judging (official: o3-mini-2025-01-31 with structured output ExtractedAnswer; Ornith cards: Claude 4.6
Opus). Send judge_prompt as the only user message; return {"id", "extracted_final_answer", "reasoning",
"correct": "yes"|"no", "confidence": 0-100, "strict": true}. The judge sees the question text only (no image),
as in the official script.

44 items to judge in /home/raahem/ornith-fusion/runs/ref_orn_hle_b81920/hle/judge_inputs.jsonl; 20 auto-verdicted (no answer) in auto_verdicts.jsonl.
Write one JSON object per line to judgments.jsonl: {"id": ..., <verdict_schema fields>}.
Then: ~/evals/text2/.venv/bin/python ~/evals/text2/judge_ingest.py /home/raahem/ornith-fusion/runs/ref_orn_hle_b81920/hle <judgments.jsonl>
